﻿char[,] charArray = new char[,]{
    {'S', 'a', 'n'},
    {'e', 'k', '!'}
};
string GetStringFromCharArray(char [,] array){
    string m = "";
    for(int i = 0; i < array.GetLength(0); i++){
        for(int j = 0; j < array.GetLength(1); j++){
            m += array[i,j];
        }
    }
    return(m);

}
Console.WriteLine(GetStringFromCharArray(charArray));