﻿Console.WriteLine("Введите строку:");
string str = Console.ReadLine()!;
bool function(string s){
    int d2 = s.Length;
    for(int i = 0; i < d2; i++){
        if(s[i] != s[d2 - i -1]){
            return(false);
        }
        
    }
    return(true);
}
bool v = function(str);
    if(v){
        Console.WriteLine("Строка является Палиндромом");   
    }
    else {
    Console.WriteLine("Строка не является Палиндромом");
    }
