﻿string str = "Hello my world";
string function(string s){
 string[] substrings = s.Split(' ');
 string strOut = "";
 for(int i = substrings.Length -1; i >= 0; i--){
    strOut += substrings[i] + " ";

 } 
 return(strOut);
}
Console.WriteLine(function(str));
