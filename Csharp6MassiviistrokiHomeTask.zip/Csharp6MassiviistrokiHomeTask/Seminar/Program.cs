﻿// Задача 1
/*
using System.Collections;

string GetStringFromCharArray(char [] array){
    string str = "";
    foreach(char c in array){
        str += c;
    }
    return str;
}
char[] chars = new char[] {'a', 'b', 'c', 'd'};
String str = GetStringFromCharArray(chars);
Console.WriteLine(str);
*/

// Задача 2
/*
char[] StirngToCharArray(string str){
    char[] chars = new char[str.Length];
    for(int i = 0; i<str.Length; i++){
        chars[i] = str[i];
    }
    return chars;
}
string str = "Hello world!";
char[] chars = StirngToCharArray(str);
foreach(char c in chars){
Console.WriteLine(c);
}
*/

//Задача 3
//вариант1
/*
int GetVoveLsCount(string str){
    string vovels = "aoyuie";
    int counter = 0;
    foreach(char c in str){
        if(vovels.Contains(c)){   //Проверка подстроки в строке.
            counter++;
        }
    }
    return counter;
}
string str = Console.ReadLine();
int countVovels = GetVoveLsCount(str);
Console.WriteLine(countVovels);
*/
//вариант2

int GetVoveLsCount(string str){
    string vovels = "aoyuie";
    int counter = 0;
    foreach(char c in str){
       foreach(char vovel in vovels){
        if(c == vovel){
            counter++;
        }
        }
    }
    return counter;
}
string str = Console.ReadLine()!;
int countVovels = GetVoveLsCount(str);
Console.WriteLine(countVovels);
