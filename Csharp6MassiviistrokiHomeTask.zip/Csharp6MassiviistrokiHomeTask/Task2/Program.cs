﻿string DoubleRegister = "aBcD1eF!";

string function(string line){
    char c;
    string str = "";
    for(int i = 0; i < line.Length; i++){
        c = line[i];
        c = char.ToLower(c);
        str+=c;
    }
    return(str);
    
}
Console.WriteLine(function(DoubleRegister));